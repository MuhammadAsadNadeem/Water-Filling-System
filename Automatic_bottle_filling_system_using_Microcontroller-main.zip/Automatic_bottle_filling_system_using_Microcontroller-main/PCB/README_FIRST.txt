I wrote the PCB TEXT OPPOSITE AS I have used antient method of making pcb using IRON and PHOTO PAPER.
